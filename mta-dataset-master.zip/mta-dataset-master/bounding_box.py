class BoundingBox:
    topLeft = None
    topRight = None
    bottomRight = None
    bottomLeft = None